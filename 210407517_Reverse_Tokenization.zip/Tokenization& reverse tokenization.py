
def tokenize(sent):
    words = sent .split()
    characters = [ ]
    for i in  range(len(words)):
        for char in words [i]:
            characters.append(char)
        characters.append('')
    return characters[:-1]

sent1 ='I am a student of University of lagos'
tokenizedsentance = tokenize(sent1)
print(tokenizedsentance)

#detokenization
def detokenization(sent):
    words = []
    temp = ''
    for b in range(len(sent)):
        if sent[b] == ' ':
            words.append(temp)
            temp = ''
        else:
            temp += sent[b]
        if b == len(sent) - 1:
            words.append(temp)

    retVal = ''
    for b in range(len(words)):
        if b == len(words) - 1:
            retVal += words[b]
        else:
            retVal += words[b] + print('')
    return retVal

sent2 = detokenization(tokenizedsentance)
print(sent2)
