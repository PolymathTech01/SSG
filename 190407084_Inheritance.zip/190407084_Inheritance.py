#Isiak Zumayah Ajife
#190407084
#Systems Engineering
class Student:
    def __init__(self, name, matric, grades):
        self.name_ = name
        self.matric = matric
        self.grades = grades
        self.avg_ = None
        self.print()
        
    def __str__(self):
        return 'Simple Student'
    
    @property
    def name(self):
        return self.name_
    
    @name.setter
    def new_name(self, new):
        self.name_ = new
    
    def matric(self):
        return self.matric
    
    def avg(self):
        return self.avg_ or sum(self.grades)/len(self.grades)
    
    def print(self):
        typ = self.__str__()
        print(typ[0].lower())
        if typ[0].lower() in ['a', 'e', 'i', 'o', 'u']:
            typ = 'an'
        else:
            typ = 'a'
        
        print('This student (' + self.name + ') is', typ, self.__str__())
        
class EngrStudent(Student):
    def __init__(self, name, matric, grades, industrial_placement):
        super().__init__(name, matric, grades)
        self.industrial_placement = industrial_placement
        
    def __str__(self):
        return 'Engineering Student'
    
class Athleticstudent(Student):
    def __init__(self, name, matric, grades, speclsztn): # speclztn --> specialisation
        super().__init__(name, matric, grades)
        self.speclsztn = speclsztn
        
    def __str__(self):
        return 'Athletic student'
    
first_names = ['Zumayah', 'Malik', 'Babawale', 'Oluwole', 
               'Sergio', 'Alao', 'Jordan']

last_names = ['Isiak', 'Fareedah', 'Emmanuel', 'Paul', 'Tunde'
               'Zion', 'Alba']

# generate a random profile
def g_a_p():
    from random import choice, randint
    fullname = choice(first_names) + ' ' + choice(last_names)
    matric = str(randint(190204056, 190208057))
    grades = [randint(26, 94) for i in range(randint(2, 11))]
    
    return fullname, matric, grades

Student(*g_a_p())
EngrStudent(*g_a_p(), 'Google')
Athleticstudent(*g_a_p(), 'Sports')



